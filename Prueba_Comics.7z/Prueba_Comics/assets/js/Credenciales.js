export const firebaseConfig = {
    apiKey: "AIzaSyAvqS3Q7saRQHzY0Hv4aDowG_4fjMyMU1g",
    authDomain: "comics-bce23.firebaseapp.com",
    projectId: "comics-bce23",
    storageBucket: "comics-bce23.firebasestorage.app",
    messagingSenderId: "449936851195",
    appId: "1:449936851195:web:ec9ed7243bf96ae6c9b05e"
  };