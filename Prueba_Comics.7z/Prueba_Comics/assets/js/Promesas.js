import { db } from "./Firebase.js";
import {collection, addDoc, getDocs, doc, deleteDoc, getDoc, updateDoc} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

export let agregarComic = async(comic)=>{
    const docRef = await addDoc(collection(db,"comic"),comic);
}

export let obtenerComics = async()=>{
    const querySnapshot = await getDocs(collection(db,"comic"));
    var comics = []
    querySnapshot.forEach((doc) => {
        let comic = {
            'id':doc.id,
            'titulo':doc.data().titulo,
            'autor':doc.data().autor,
            'editorial':doc.data().editorial,
            'pais':doc.data().pais,
            'fecha':doc.data().fecha,
            'genero':doc.data().genero,
            'valoracion':doc.data().valoracion,
            'traduccionEspaniol':doc.data().traduccinEspaniol
        }
        comics.push(comic)
        console.log(doc.id, " => ",doc.data());
    });
        return comics;
}

export let eliminarComic = async(idComic)=>{
    await deleteDoc(doc(db,"comic",idComic));
}

export let obtenerComic = async (idComic)=>{
    const docRef = doc(db,"comic",idComic);
    const docSnap = await getDoc(docRef);
    let comic = {
        'id':docSnap.id,
        'titulo':docSnap.data().titulo,
        'autor':docSnap.data().autor,
        'editorial':docSnap.data().editorial,
        'pais':docSnap.data().pais,
        'fecha':docSnap.data().fecha,
        'genero':docSnap.data().genero,
        'valoracion':docSnap().valoracion,
        'traduccionEspaniol':docSnap.data().traduccionEspaniol
    }
    return comic;
}

export let actualizarComic= async(id,p)=>{
    const docRef =await doc(db,"comic",id);
    console.log(p);
    updateDoc(docRef,{...p});
}