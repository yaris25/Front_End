import { eliminarComic, obtenerComics } from "./Promesas.js";

window.addEventListener("load",()=>{
    var comics = obtenerComics()
    console.log(comics)
    var eTBody = document.getElementById("cuerpoTabla");
    comics.then((listado)=>{
        let filas = ""
        listado.forEach((p)=>{
            filas += "<tr>"
            filas += "<td>"+p.titulo+"<td/>"
            filas += "<td>"+p.autor+"<td/>"
            filas += "<td>"+p.editorial+"<td/>"
            filas += "<td>"+p.pais+"<td/>"
            filas += "<td>"+p.fecha+"<td/>"
            filas += "<td>"+p.genero+"<td/>"
            filas += "<td>"+p.valoracion+"<td/>"
            filas += "<td>"+p.traduccionEspaniol+"<td/>"
            filas += "<td><button id='mod"+ p.id +"'>Modificar</button></td>"
            filas += "<td><button id='eli"+ p.id +"'>Eliminar</button></td>"
            filas += "</tr>"
        })
        console.log(filas)
        eTBody.innerHTML = filas;

        listado.forEach((p)=>{
            let btnEliminar = document.getElementById("eli"+p.id);
            btnEliminar.addEventListener("click",()=>{
                if (confirm("Desea eliminar el comic "+p.titulo+" ?")){
                    console.log("Logro eliminar")
                    eliminarComic(p.id).then(()=>{
                        console.log("Eliminado con exito")
                        location.reload()
                    }).catch((e)=>{
                        console.log("No se logro eliminar: "+e)
                    })
                }else{
                    console.log("No eliminaste")
                }
            })
            let btnActualizar = document.getElementById("mod"+p.id);
            btnActualizar.addEventListener("click",()=>{
                alert("Vamos a redireccionar con el id"+p.id);
                window.location.href = "./actualizar.html?id="+p.id;
            })
        })
    })
})