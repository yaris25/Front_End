import { agregarComic } from "./Promesas.js";

window.addEventListener("load",()=>{
    console.log("Se logro señores!!")
    document.getElementById("btnAgregar").addEventListener("click",()=>{
        console.log("Diste click");
        //Recuperar los elementos
        let eTitulo = document.getElementById("titulo");
        let eAutor = document.getElementById("autor");
        let eEditorial = document.getElementById("editorial");
        let ePais = document.getElementById("pais");
        let eFecha = document.getElementById("fecha");
        let eGenero = document.getElementById("genero");
        let eValoracion = document.getElementById("valoracion");
        let eTraduccionEspaniol = document.getElementById("traduccionEspaniol")
        //Recuperar el contenido de los elementos
        let vTitulo = eTitulo.value;
        let vAutor = eAutor.value;
        let vEditorial = eEditorial.value;
        let vPais = ePais.value;
        let vFecha = eFecha.value;
        let vGenero = eGenero.value;
        let vValoracion = eValoracion.value;
        //Recuperar los checkbox si se encuentran chequeados
        let vTraduccionEspaniol = eTraduccionEspaniol.checked;
        console.log(vTitulo);
        console.log(vAutor);
        console.log(vEditorial);
        console.log(vPais);
        console.log(vFecha);
        console.log(vGenero);
        console.log(vValoracion);
        console.log(vTraduccionEspaniol);
        let comic ={
            'titulo':vTitulo,
            'autor':vAutor,
            'editorial':vEditorial,
            'pais':vPais,
            'fecha':vFecha,
            'genero':vGenero,
            'traduccionEspaniol':vTraduccionEspaniol,
        };
        agregarComic(comic);
        console.log(comic);
    })
})