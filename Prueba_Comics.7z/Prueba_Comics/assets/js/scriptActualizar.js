import { actualizarComic,obtenerComic } from "./Promesas.js";

window.addEventListener("load",()=>{
    alert("Se logro")
    //Recuperar los parametros
    let valores = window.location.search;
    console.log(valores)
    //Se crea la instancia de los valores
    const urlParams = new URLSearchParams(valores);
    //Accedemos a los valores
    var id = urlParams.get('id');
    console.log(id);
    //Recuperamos los objetos asociados con la id
    obtenerComic(id).then((p)=>{
        console.log(p);
            //Recuperar los elementos
            let titulo = document.getElementById("titulo");
            let autor = document.getElementById("autor");
            let editorial = document.getElementById("editorial");
            let pais = document.getElementById("pais");
            let fecha = document.getElementById("fecha");
            let genero = document.getElementById("genero");
            let valoracion = document.getElementById("valoracion");
            let traduccionEspaniol = document.getElementById("traduccionEspaniol");
            //Cargarmos los valores actuales
            titulo.value = p.titulo;
            autor.value = p.autor;
            editorial.value = p.editorial;
            pais.value = p.pais;
            fecha.value = p.fecha;
            genero.value = p.genero;
            valoracion.value = p.valoracion;
            //Se valida si esta chequeado el checkbox
            if (p.traduccionEspaniol) {
                traduccionEspaniol.checked = true;
            }
    })
    //Asignar la accion al boton actualizar
    let btnActualizar = document.getElementById("btnActualizar");
    btnActualizar.addEventListener("click",()=>{
        //Recuperar los elementos
        let eTitulo = document.getElementById("titulo");
        let eAutor = document.getElementById("autor");
        let eEditorial = document.getElementById("editorial");
        let ePais = document.getElementById("pais");
        let eFecha = document.getElementById("fecha");
        let eGenero = document.getElementById("genero");
        let eValoracion = document.getElementById("valoracion");
        let eTraduccionEspaniol = document.getElementById("traduccionEspaniol")
        //Recuperar el contenido de los elementos
        let vTitulo = eTitulo.value;
        let vAutor = eAutor.value;
        let vEditorial = eEditorial.value;
        let vPais = ePais.value;
        let vFecha = eFecha.value;
        let vGenero = eGenero.value;
        let vValoracion = eValoracion.value;
        //recuperar los checkbox si se encuentran chequeados
        let vTraduccionEspaniol = eTraduccionEspaniol.checked;
        console.log(vTitulo);
        console.log(vAutor);
        console.log(vEditorial);
        console.log(vPais);
        console.log(vFecha);
        console.log(vGenero);
        console.log(vValoracion);
        console.log(vTraduccionEspaniol);
        let comic = {
            'titulo':vTitulo,
            'autor':vAutor,
            'editorial':vEditorial,
            'pais':vPais,
            'fecha':vFecha,
            'genero':vGenero,
            'traduccionEspaniol':vTraduccionEspaniol,
        };
        actualizarComic(id,comic).then(()=>{
            alert("Se actualiza con exito el comic");
        }).catch((e)=>{
            console.log(e)
        })
    })
})